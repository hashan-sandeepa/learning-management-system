<!DOCTYPE html>
<?php
   include('session.php');
?>
<html>
<head>
	<title>LMS - Home</title>
	<link href="../css/home.css" rel="stylesheet" type="text/css">
	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
</head>
<body>
<div id="main">
	<div id="header">
		<div>
			<a href = "logout.php" style="float:right;display:inline-block;margin-right:20px;">Sign Out</a>
			<p style="float:right;margin-right:10px;display:inline-block;margin-top:0px;">Logged as <?php echo $user_check ?> <p> 
		</div>
	</div>
	<div id="slider">
		<p>slider</p>
	</div>
	<div id="container">
   		<div id="center">
   		center
   		</div>
   		<div id="left">
   			<div id="left-upper">
   				left-upper
   			</div>
   			<div id="left-lower">
   				left-lower
   			</div>	
   		</div>
   		<div id="right">
   			<div id="right-upper">
   				right-upper
   			</div>
   			<div id="right-lower">
   				right-lower
   			</div>
   		</div>
	</div>
	<div id="footer">
		<p>footer</p>
	</div>
</div>
</body>
</html>